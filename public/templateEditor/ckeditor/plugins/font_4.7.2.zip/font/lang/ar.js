/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'font', 'ar', {
	fontSize: {
		label: 'حجم الخط',
		voiceLabel: 'حجم الخط',
		panelTitle: 'حجم الخط'
	},
	label: 'خط',
	panelTitle: 'حجم الخط',
	voiceLabel: 'حجم الخط'
} );
